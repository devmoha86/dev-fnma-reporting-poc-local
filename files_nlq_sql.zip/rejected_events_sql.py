"""
rejected_events_sql.py
----------------------
SQLite-backed version of rejected_events.py.

Key design decisions:
  1. SQLite at dev/test time; swap DB_URL for Aurora PostgreSQL (same SQL)
     and Athena (same SQL via PyAthena) in production — no logic changes.
  2. Every endpoint runs raw SQL so the NLQ layer can read, replay, and
     tweak the exact same queries stored in rejected_events_nlq_context.json.
  3. apply_filters() builds a parameterised WHERE clause used identically
     across all three endpoints — summary, by-servicer, and detail.
  4. sort_detail_df() is replaced by ORDER BY injection via allowlist.
  5. The CSV is loaded once at startup into the SQLite table so local dev
     works without any external database.

Compatibility note:
  The response shapes are identical to the original rejected_events.py so
  the Angular frontend and NLQ context file require no changes.
"""

import math
import sqlite3
import os
from contextlib import contextmanager
from datetime import datetime
from typing import Optional

import pandas as pd
from fastapi import Query, HTTPException

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Local SQLite DB path — override with env var for Aurora/Athena in production
DB_PATH = os.getenv("REJECTED_EVENTS_DB", "data/rejected_events.db")
CSV_PATH = os.getenv("REJECTED_EVENTS_CSV", "data/rejected_events.csv")
TABLE_NAME = "rejected_events"

# Sort allowlist — prevents SQL injection via ORDER BY
ALLOWED_SORT_COLUMNS = {
    "event_id", "loan_id", "servicer_id", "servicer_name",
    "rejection_reason", "age_days", "status", "timestamp",
    "activity_period",
}
DEFAULT_SORT_BY  = "age_days"
DEFAULT_SORT_DIR = "DESC"


# ---------------------------------------------------------------------------
# Database bootstrap — load CSV into SQLite table at startup
# ---------------------------------------------------------------------------

def _bootstrap_db() -> None:
    """
    Load rejected_events.csv into SQLite on first run.
    If the table already exists and is populated, this is a no-op.

    Schema inferred from the CSV and the original DataFrame logic:
        event_id        TEXT
        loan_id         TEXT
        servicer_id     TEXT
        servicer_name   TEXT
        rejection_reason TEXT
        age_days        INTEGER
        status          TEXT        -- 'Outstanding' | 'Resolved'
        timestamp       TEXT
        activity_period TEXT        -- 'MM/YYYY'
        is_delinquent   INTEGER     -- 0 | 1  (SQLite boolean)
    """
    print(f"[startup] bootstrapping SQLite db at {DB_PATH} ...")
    os.makedirs(os.path.dirname(DB_PATH) if os.path.dirname(DB_PATH) else ".", exist_ok=True)

    df = pd.read_csv(CSV_PATH)

    # Normalise is_delinquent to integer boolean for SQL WHERE clauses
    df["is_delinquent"] = (
        df["is_delinquent"].astype(str).str.lower().map({"true": 1, "false": 0}).fillna(0).astype(int)
    )

    with sqlite3.connect(DB_PATH) as conn:
        # Use if_exists="replace" so re-running with a new CSV picks up changes
        df.to_sql(TABLE_NAME, conn, if_exists="replace", index=False)
        row_count   = conn.execute(f"SELECT COUNT(*) FROM {TABLE_NAME}").fetchone()[0]
        svc_count   = conn.execute(f"SELECT COUNT(DISTINCT servicer_id) FROM {TABLE_NAME}").fetchone()[0]

    print(f"[startup] {row_count} rows, {svc_count} servicers ready in SQLite")


# ---------------------------------------------------------------------------
# Connection helper
# ---------------------------------------------------------------------------

@contextmanager
def get_db():
    """Yield a SQLite connection. Swap this for asyncpg/PyAthena in production."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row          # access columns by name
    try:
        yield conn
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Shared SQL helpers
# ---------------------------------------------------------------------------

def _build_where(
    servicer_id:     Optional[str] = None,
    activity_period: Optional[str] = None,
    status:          Optional[str] = None,
) -> tuple[str, list]:
    """
    Build a parameterised WHERE clause from optional filter values.

    Returns:
        clause  -- SQL fragment, e.g. "WHERE servicer_id = ? AND status = ?"
        params  -- list of bound values in the same order

    SQL stored in NLQ context:
        SELECT ... FROM rejected_events
        {where_clause}

    The NLQ engine substitutes the same clause to answer filter-scoped questions.
    """
    conditions: list[str] = []
    params:     list      = []

    if servicer_id:
        conditions.append("CAST(servicer_id AS TEXT) = ?")
        params.append(servicer_id)

    if activity_period:
        conditions.append("activity_period = ?")
        params.append(activity_period)

    if status:
        conditions.append("status = ?")
        params.append(status)

    clause = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    return clause, params


def _safe_sort(sort_by: str, sort_dir: str) -> tuple[str, str]:
    """Validate sort column and direction against allowlist — prevents SQL injection."""
    col = sort_by  if sort_by  in ALLOWED_SORT_COLUMNS else DEFAULT_SORT_BY
    dir = sort_dir.upper() if sort_dir.upper() in ("ASC", "DESC") else DEFAULT_SORT_DIR
    return col, dir


def _format_as_of_timestamp() -> str:
    """Return server-local time formatted with required ET suffix."""
    return datetime.now().strftime("%m/%d/%Y %I:%M %p") + " ET"


def _resolve_activity_period(
    where_clause: str,
    params:       list,
    requested:    Optional[str],
) -> str:
    """
    Resolve the activity_period value to include in responses.
    Priority: explicit request → first row in filtered set → first row overall → fallback.

    SQL equivalent used by NLQ:
        SELECT activity_period FROM rejected_events {where_clause} LIMIT 1
    """
    if requested:
        return requested

    sql = f"SELECT activity_period FROM {TABLE_NAME} {where_clause} LIMIT 1"
    with get_db() as conn:
        row = conn.execute(sql, params).fetchone()
        if row:
            return str(row["activity_period"])

        row = conn.execute(f"SELECT activity_period FROM {TABLE_NAME} LIMIT 1").fetchone()
        if row:
            return str(row["activity_period"])

    return "05/2026"


# ---------------------------------------------------------------------------
# Endpoint 1 — GET /api/rejected-events/summary
# ---------------------------------------------------------------------------

# SQL powering this endpoint (stored verbatim in nlq_context.json)
SUMMARY_SQL = """
SELECT
    COUNT(*)                                                        AS total_rows,
    SUM(CASE WHEN status = 'Outstanding' THEN 1 ELSE 0 END)        AS outstanding_events,
    COUNT(DISTINCT loan_id)                                         AS rejected_loans,
    COUNT(DISTINCT CASE WHEN status = 'Outstanding'
                        THEN loan_id END)                           AS outstanding_loans
FROM rejected_events
{where_clause}
"""


def get_rejected_events_summary_sql(
    servicer_id:     Optional[str] = None,
    activity_period: Optional[str] = None,
) -> dict:
    """
    Aggregate summary powering:
      - KPI card: Total Loans
      - KPI card: Avg Delinquency
      - KPI card: Portfolio Balance
      - Chart:    Servicer Status Distribution
    """
    where_clause, params = _build_where(servicer_id, activity_period)

    sql = SUMMARY_SQL.format(where_clause=where_clause)

    with get_db() as conn:
        row = conn.execute(sql, params).fetchone()

    total_rows        = row["total_rows"]        or 0
    outstanding_events= row["outstanding_events"]or 0
    rejected_loans    = row["rejected_loans"]    or 0
    outstanding_loans = row["outstanding_loans"] or 0

    pct_of_total_delinquent = (
        round((outstanding_loans / total_rows) * 100, 1) if total_rows else 0.0
    )

    return {
        "outstanding_rejected_events": outstanding_events,
        "rejected_loans":              rejected_loans,
        "pct_of_total_delinquent":     pct_of_total_delinquent,
        "activity_period":             _resolve_activity_period(where_clause, params, activity_period),
        "as_of_timestamp":             _format_as_of_timestamp(),
    }


# ---------------------------------------------------------------------------
# Endpoint 2 — GET /api/rejected-events/by-servicer
# ---------------------------------------------------------------------------

# SQL powering this endpoint (stored verbatim in nlq_context.json)
BY_SERVICER_SQL = """
SELECT
    servicer_id,
    COUNT(*)                                                        AS group_total,
    SUM(CASE WHEN status = 'Outstanding' THEN 1 ELSE 0 END)        AS svc_outstanding,
    COUNT(DISTINCT loan_id)                                         AS svc_rejected_loans,
    COUNT(DISTINCT CASE WHEN status = 'Outstanding'
                        THEN loan_id END)                           AS svc_outstanding_loans
FROM rejected_events
{where_clause}
GROUP BY servicer_id
ORDER BY svc_outstanding DESC
"""

# Totals row appended after the per-servicer rows
TOTALS_SQL = """
SELECT
    'Total'                                                          AS servicer_id,
    COUNT(*)                                                         AS group_total,
    SUM(CASE WHEN status = 'Outstanding' THEN 1 ELSE 0 END)         AS svc_outstanding,
    COUNT(DISTINCT loan_id)                                          AS svc_rejected_loans,
    COUNT(DISTINCT CASE WHEN status = 'Outstanding'
                        THEN loan_id END)                            AS svc_outstanding_loans
FROM rejected_events
{where_clause}
"""


def get_rejected_events_by_servicer_sql(
    servicer_id:     Optional[str] = None,
    activity_period: Optional[str] = None,
) -> list:
    """
    Per-servicer breakdown powering:
      - Chart: Delinquency Rate Trend (%)
      - Chart: Loan Count by Region & Servicer
      - Chart: Portfolio Balance — USD Millions

    Returns a list of servicer rows plus a synthetic 'Total' row at the end.
    """
    where_clause, params = _build_where(servicer_id, activity_period)

    sql_rows   = BY_SERVICER_SQL.format(where_clause=where_clause)
    sql_totals = TOTALS_SQL.format(where_clause=where_clause)

    rows = []
    with get_db() as conn:
        for r in conn.execute(sql_rows, params).fetchall():
            group_total = r["group_total"] or 1     # guard division by zero
            svc_pct = round(
                (r["svc_outstanding_loans"] / group_total) * 100, 1
            ) if group_total else 0.0

            rows.append({
                "servicer_id":               str(r["servicer_id"]),
                "outstanding_rejected_events": int(r["svc_outstanding"]),
                "rejected_loans":             int(r["svc_rejected_loans"]),
                "pct_of_total_delinquent":    svc_pct,
            })

        # Totals row
        t = conn.execute(sql_totals, params).fetchone()
        if t:
            gt = t["group_total"] or 1
            rows.append({
                "servicer_id":               "Total",
                "outstanding_rejected_events": int(t["svc_outstanding"] or 0),
                "rejected_loans":             int(t["svc_rejected_loans"] or 0),
                "pct_of_total_delinquent":    round(
                    (t["svc_outstanding_loans"] / gt) * 100, 1
                ) if gt else 0.0,
            })

    return rows


# ---------------------------------------------------------------------------
# Endpoint 3 — GET /api/rejected-events/detail
# ---------------------------------------------------------------------------

# SQL powering this endpoint (stored verbatim in nlq_context.json)
DETAIL_SQL = """
SELECT
    event_id,
    loan_id,
    servicer_id,
    servicer_name,
    rejection_reason,
    age_days,
    status,
    timestamp,
    activity_period,
    is_delinquent
FROM rejected_events
{where_clause}
ORDER BY {sort_col} {sort_dir}
LIMIT {page_size} OFFSET {offset}
"""

DETAIL_COUNT_SQL = """
SELECT COUNT(*) AS total
FROM rejected_events
{where_clause}
"""


def get_rejected_events_detail_sql(
    servicer_id:     Optional[str] = None,
    activity_period: Optional[str] = None,
    status:          Optional[str] = None,
    page:            int           = 1,
    page_size:       int           = 20,
    sort_by:         str           = DEFAULT_SORT_BY,
    sort_dir:        str           = DEFAULT_SORT_DIR,
) -> dict:
    """
    Paginated row-level detail powering the Table tab view.

    Returns full pagination envelope: total, page, page_size, total_pages, data[].
    """
    where_clause, params = _build_where(servicer_id, activity_period, status)
    sort_col, sort_dir_safe = _safe_sort(sort_by, sort_dir)

    offset = (max(page, 1) - 1) * page_size

    # Count total matching rows
    count_sql = DETAIL_COUNT_SQL.format(where_clause=where_clause)
    with get_db() as conn:
        total = conn.execute(count_sql, params).fetchone()["total"] or 0

    total_pages = math.ceil(total / page_size) if total else 0

    # Fetch the page
    data_sql = DETAIL_SQL.format(
        where_clause=where_clause,
        sort_col=sort_col,
        sort_dir=sort_dir_safe,
        page_size=page_size,
        offset=offset,
    )
    with get_db() as conn:
        page_rows = conn.execute(data_sql, params).fetchall()

    data = [
        {
            "event_id":        str(row["event_id"]),
            "loan_id":         str(row["loan_id"]),
            "servicer_id":     str(row["servicer_id"]),
            "servicer_name":   str(row["servicer_name"]),
            "rejection_reason":str(row["rejection_reason"]),
            "age_days":        int(row["age_days"]),
            "status":          str(row["status"]),
            "timestamp":       str(row["timestamp"]),
            "activity_period": str(row["activity_period"]),
            "is_delinquent":   bool(row["is_delinquent"]),
        }
        for row in page_rows
    ]

    return {
        "total":       total,
        "page":        page,
        "page_size":   page_size,
        "total_pages": total_pages,
        "data":        data,
    }


# ---------------------------------------------------------------------------
# FastAPI route registration
# ---------------------------------------------------------------------------

def register_rejected_events_routes(app) -> None:
    """
    Register all rejected-events endpoints on the main FastAPI app instance.
    Drop-in replacement for the original register_rejected_events_routes().
    Response shapes are identical — frontend requires no changes.
    """

    # Run CSV → SQLite bootstrap once at startup
    _bootstrap_db()

    @app.get("/api/rejected-events/summary", tags=["rejected-events"])
    def get_rejected_events_summary(
        servicer_id:     Optional[str] = Query(None, description="Filter by servicer ID"),
        activity_period: Optional[str] = Query(None, description="Filter by activity period (MM/YYYY)"),
    ):
        """
        Aggregate summary used by KPI cards and Status Distribution chart.

        SQL:
            SELECT
                COUNT(*) AS total_rows,
                SUM(CASE WHEN status = 'Outstanding' THEN 1 ELSE 0 END) AS outstanding_events,
                COUNT(DISTINCT loan_id) AS rejected_loans,
                COUNT(DISTINCT CASE WHEN status = 'Outstanding' THEN loan_id END) AS outstanding_loans
            FROM rejected_events
            [WHERE servicer_id = ? AND activity_period = ?]
        """
        return get_rejected_events_summary_sql(servicer_id, activity_period)

    @app.get("/api/rejected-events/by-servicer", tags=["rejected-events"])
    def get_rejected_events_by_servicer(
        servicer_id:     Optional[str] = Query(None, description="Filter by servicer ID"),
        activity_period: Optional[str] = Query(None, description="Filter by activity period (MM/YYYY)"),
    ):
        """
        Per-servicer breakdown used by Delinquency Rate Trend, Loan Count, and Portfolio Balance charts.

        SQL:
            SELECT
                servicer_id,
                COUNT(*) AS group_total,
                SUM(CASE WHEN status = 'Outstanding' THEN 1 ELSE 0 END) AS svc_outstanding,
                COUNT(DISTINCT loan_id) AS svc_rejected_loans,
                COUNT(DISTINCT CASE WHEN status = 'Outstanding' THEN loan_id END) AS svc_outstanding_loans
            FROM rejected_events
            [WHERE servicer_id = ? AND activity_period = ?]
            GROUP BY servicer_id
            ORDER BY svc_outstanding DESC
        """
        return get_rejected_events_by_servicer_sql(servicer_id, activity_period)

    @app.get("/api/rejected-events/detail", tags=["rejected-events"])
    def get_rejected_events_detail(
        servicer_id:     Optional[str] = Query(None,            description="Filter by servicer ID"),
        activity_period: Optional[str] = Query(None,            description="Filter by activity period (MM/YYYY)"),
        status:          str           = Query("Outstanding",   pattern="^(Outstanding|Resolved)$",
                                               description="Status filter"),
        page:            int           = Query(1,   ge=1,       description="Page number (1-indexed)"),
        page_size:       int           = Query(20,  ge=1, le=100, description="Rows per page"),
        sort_by:         str           = Query(DEFAULT_SORT_BY, description="Sort column"),
        sort_dir:        str           = Query(DEFAULT_SORT_DIR, pattern="^(asc|desc|ASC|DESC)$",
                                               description="Sort direction"),
    ):
        """
        Paginated row-level detail used by the Table tab view.

        SQL:
            SELECT event_id, loan_id, servicer_id, servicer_name,
                   rejection_reason, age_days, status, timestamp,
                   activity_period, is_delinquent
            FROM rejected_events
            [WHERE servicer_id = ? AND activity_period = ? AND status = ?]
            ORDER BY {sort_col} {sort_dir}
            LIMIT {page_size} OFFSET {offset}
        """
        if sort_by not in ALLOWED_SORT_COLUMNS:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid sort_by '{sort_by}'. Allowed: {sorted(ALLOWED_SORT_COLUMNS)}"
            )
        return get_rejected_events_detail_sql(
            servicer_id, activity_period, status, page, page_size, sort_by, sort_dir
        )
